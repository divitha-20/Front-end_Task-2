import React, { Component } from "react";
import "./header.css";
import "./icons.css";

export class Header extends Component {
  render() {
    return (
      <body>
        <div>
          {/* navigation */}
          <nav
            class="navbar navbar-expand-lg navbar-light fixed-top"
            data-spy="affix"
            data-offset-top="0"
          >
            <div class="container">
              <a class="navbar-brand" href="#">
                <img src="assets/imgs/logo.svg" alt="" />
              </a>
              <button
                class="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto align-items-center">
                  <li class="nav-item">
                    <a class="nav-link" href="#home">
                      Home
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#about">
                      About
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#service">
                      Service
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#testmonial">
                      Testmonial
                    </a>
                  </li>
                  <li class="nav-item">
                    <a
                      class="- btn btn-primary rounded ml-4"
                      href="components.html"
                    >
                      Contact Us
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
          {/* end of navigation */}

          {/* header */}
          <header class="header" id="home">
            <div class="container">
              <div class="infos">
                <h6 class="subtitle">We Are</h6>
                <h6 class="title">Team A49</h6>
                <p>Full Stack Developers</p>

                <div class="buttons pt-3">
                  <button class="btn btn-primary rounded">HIRE US</button>
                  <button class="btn btn-dark rounded">DOWNLOAD CV</button>
                </div>
              </div>
              <div class="img-holder">
                <img src="girls.png" alt="" />
              </div>
            </div>
          </header>
          {/* end of header */}

          {/* About */}
          <section id="about" class="section mt-3">
            <div class="container mt-5">
              <div class="row text-center text-md-left">
                <div class="col-md-3">
                  <img src="abt_us.png" alt="" class="abt_us" />
                </div>
                <div class="pl-md-4 col-md-9">
                  <h6 class="title">Team A49</h6>
                  <p class="subtitle">Full Stack Developers</p>
                  <p class="p1">
                    We are a group of three budding software developers from
                    Rajalakshmi Institute Of Technology. We are currently
                    focussed in developing our skills in Full Stack Web
                    Development. We are building our own portfolio website as
                    the first step towards our journey in Full Stack
                    Development. We use this website to showcase our talents
                    through the different domains of Computer Science and
                    Engineering. We three are skilled on intermediate level
                    among different skillsets in the field of web development.
                  </p>
                  <p class="p2">
                    We three are skilled on intermediate level among different
                    skillsets in the field of web development. We three come and
                    work together as a team to build this prestigious project
                    using MERN Stack.<br/><br/> 
                    Our Team Members: <br/>
                      Charumathy T - 202001035<br/>
                      Divitha PM - 202001046<br/>
                      Divya Varsha - 202001047
                  </p>
                  <button class="btn btn-primary rounded mt-3">
                    DOWNLOAD CV
                  </button>
                </div>
              </div>
            </div>
          </section>
          {/* end of about */}

          {/* Service */}
          <section id="service" class="section">
            <div class="container text-center">
              <h6 class="subtitle">Service</h6>
              <h6 class="section-title mb-4">What We Do</h6>
              <p class="mb-5 pb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. In
                alias dignissimos. <br /> rerum commodi corrupti, temporibus non
                quam.
              </p>

              <div class="row">
                <div class="col-sm-6 col-md-3 mb-4">
                  <div class="custom-card card border">
                    <div class="card-body">
                      <i class="icon ti-crown"></i>
                      <h5>UI/UX Design</h5>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-md-3 mb-4">
                  <div class="custom-card card border">
                    <div class="card-body">
                      <i class="icon ti-desktop"></i>
                      <h5>Web Design</h5>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-md-3 mb-4">
                  <div class="custom-card card border">
                    <div class="card-body">
                      <i class="icon ti-mobile"></i>
                      <h5>App Design</h5>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-md-3 mb-4">
                  <div class="custom-card card border">
                    <div class="card-body">
                      <i class="icon ti-bar-chart"></i>
                      <h5>SEO</h5>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {/* end of service */}

          {/* testimonials */}
          <section id="testmonial" class="section">
            <div class="container text-center">
              <h6 class="subtitle">Testmonial</h6>
              <h6 class="section-title mb-4">What People Say About Me</h6>
              <p class="mb-5 pb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. In
                alias dignissimos. <br /> rerum commodi corrupti, temporibus non
                quam.
              </p>

              <div
                id="carouselExampleIndicators"
                class="carousel slide"
                data-ride="carousel"
              >
                <ol class="carousel-indicators">
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="0"
                    class="active"
                  ></li>
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="1"
                  ></li>
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="2"
                  ></li>
                </ol>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <div class="card testmonial-card border">
                      <div class="card-body">
                        <img src="assets/imgs/avatar-1.jpg" alt="" />
                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisicing
                          elit. Magnam nostrum voluptates in enim vel amet?
                        </p>
                        <h1 class="title">Emma Re</h1>
                        <h1 class="subtitle">Graphic Designer</h1>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="card testmonial-card border">
                      <div class="card-body">
                        <img src="assets/imgs/avatar-2.jpg" alt="" />
                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisicing
                          elit. Magnam nostrum voluptates in enim vel amet?
                        </p>
                        <h1 class="title">James Bert</h1>
                        <h1 class="subtitle">Web Designer</h1>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="card testmonial-card border">
                      <div class="card-body">
                        <img src="assets/imgs/avatar-3.jpg" alt="" />
                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisicing
                          elit. Magnam nostrum voluptates in enim vel amet?
                        </p>
                        <h1 class="title">Michael Abra</h1>
                        <h1 class="subtitle">Web Developer</h1>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {/* end of testimonials */}

          {/* con us */}
          <section id="contact" class="position-relative section">
            <div class="container text-center">
              <h6 class="subtitle">Contact</h6>
              <h6 class="section-title mb-4">Get In Touch With Me</h6>
              <p class="mb-5 pb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. In
                alias dignissimos. <br /> rerum commodi corrupti, temporibus non
                quam.
              </p>

              <div class="contact text-left">
                <div class="form">
                  <h6 class="subtitle">Available 24/7</h6>
                  <h6 class="section-title mb-4">Get In Touch</h6>
                  <form>
                    <div class="form-group">
                      <input
                        type="email"
                        class="form-control"
                        id="exampleInputEmail1"
                        aria-describedby="emailHelp"
                        placeholder="Enter email"
                        required
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="password"
                        class="form-control"
                        id="exampleInputPassword1"
                        placeholder="Password"
                        required
                      />
                    </div>
                    <div class="form-group">
                      <textarea
                        name="contact-message"
                        id=""
                        cols="30"
                        rows="5"
                        class="form-control"
                        placeholder="Message"
                      ></textarea>
                    </div>
                    <button
                      type="submit"
                      class="btn btn-primary btn-block rounded w-lg"
                    >
                      Send Message
                    </button>
                  </form>
                </div>
                <div class="contact-infos">
                  <div class="item">
                    <i class="ti-location-pin"></i>
                    <div class="">
                      <h5>Location</h5>
                      <p>xyz</p>
                    </div>
                  </div>
                  <div class="item">
                    <i class="ti-mobile"></i>
                    <div>
                      <h5>Phone Number</h5>
                      <p>xyz</p>
                    </div>
                  </div>
                  <div class="item">
                    <i class="ti-email"></i>
                    <div class="mb-0">
                      <h5>Email Address</h5>
                      <p>xyz@gmail.com</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="map">
              <iframe src="https://snazzymaps.com/embed/61257"></iframe>
            </div>
          </section>
          {/* end of con us */}
        </div>
      </body>
    );
  }
}

export default Header;
